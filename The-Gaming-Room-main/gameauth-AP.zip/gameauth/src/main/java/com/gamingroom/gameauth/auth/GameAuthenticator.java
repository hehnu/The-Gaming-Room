package com.gamingroom.gameauth.auth;

import io.dropwizard.auth.AuthenticationException;
import io.dropwizard.auth.Authenticator;
import io.dropwizard.auth.basic.BasicCredentials;

import java.util.Map;
import java.util.Optional;
import java.util.Set;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;

/**
 * GameAuthenticator
 * ------------------------------------------------------------
 * This class handles user authentication using Basic Authentication.
 * It validates credentials provided by the client and creates a
 * GameUser object if authentication succeeds.
 */
public class GameAuthenticator implements Authenticator<BasicCredentials, GameUser> {

    /**
     * Defines a hardcoded list of valid users and their roles.
     * In a production system, this data would be fetched from a database.
     */
    private static final Map<String, Set<String>> VALID_USERS = ImmutableMap.of(
        "guest", ImmutableSet.of(),
        "user", ImmutableSet.of("USER"),
        "admin", ImmutableSet.of("ADMIN", "USER")
    );

    /**
     * Authenticates incoming credentials using Basic Authentication.
     * If the username exists and the password matches "password",
     * a new GameUser instance is created with assigned roles.
     */
    @Override
    public Optional<GameUser> authenticate(BasicCredentials credentials) throws AuthenticationException {

        // Check if the username exists in the valid user map and password matches
        if (VALID_USERS.containsKey(credentials.getUsername()) && "password".equals(credentials.getPassword())) {

            /**
             * FIXED: Created a new GameUser instance for the authenticated user.
             * This assigns the username and associated roles from VALID_USERS.
             * The Optional wrapper ensures that authentication success or failure
             * is handled safely by Dropwizard.
             */
            GameUser authenticatedUser = new GameUser(credentials.getUsername(), VALID_USERS.get(credentials.getUsername()));
            return Optional.of(authenticatedUser);
        }

        // If username/password are invalid, return empty (authentication fails)
        return Optional.empty();
    }
}
