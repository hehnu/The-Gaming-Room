package com.gamingroom.gameauth;

import io.dropwizard.Configuration;

/**
 * GameAuthConfiguration
 * ------------------------------------------------------------
 * This class defines the configuration settings for the GameAuth
 * Dropwizard application.
 *
 * For this project, no custom fields are required, but this class
 * can easily be expanded to include them in the future.
 *
 * Example (for future use):
 *  @NotEmpty
 *  private String databaseUrl;
 *
 *  @JsonProperty
 *  public String getDatabaseUrl() { return databaseUrl; }
 */
public class GameAuthConfiguration extends Configuration {

    // No custom configuration properties required.


}
