package com.gamingroom.gameauth.healthcheck;

import com.codahale.metrics.health.HealthCheck;
import java.util.Base64;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * AppHealthCheck
 * ------------------------------------------------------------
 * Verifies that the /gameusers endpoint is running and accessible.
 * Uses Basic Authentication to validate the server responds correctly.
 */
public class AppHealthCheck extends HealthCheck {

    private final Client client;

    public AppHealthCheck(Client client) {
        this.client = client;
    }

    @Override
    protected Result check() throws Exception {
        WebTarget target = client.target("http://localhost:8080/gameusers");
        Invocation.Builder invocationBuilder = target.request(MediaType.APPLICATION_JSON);

        /**
         * FIXED: Added Basic Authentication header so the health check
         * can access a protected endpoint. Uses user:password credentials.
         */
        String basicAuth = "Basic " + Base64.getEncoder()
                .encodeToString("user:password".getBytes());
        invocationBuilder.header("Authorization", basicAuth);

        Response response = invocationBuilder.get();

        if (response.getStatus() == 200) {
            return Result.healthy();
        } else {
            return Result.unhealthy("GameUser endpoint returned status: " + response.getStatus());
        }
    }
}
