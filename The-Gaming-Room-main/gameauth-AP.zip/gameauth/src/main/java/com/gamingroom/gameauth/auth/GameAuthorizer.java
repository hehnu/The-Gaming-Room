package com.gamingroom.gameauth.auth;

import io.dropwizard.auth.Authorizer;

/**
 * GameAuthorizer
 * This class performs role-based authorization for authenticated users.
 * After a user is authenticated, this method checks whether they are
 * permitted to access a given resource based on their assigned roles.
 */
public class GameAuthorizer implements Authorizer<GameUser> {

    /**
     * FIXED: Implemented the authorization logic that checks if the
     * authenticated user possesses the required role to access a resource.
     * 
     * The @RolesAllowed annotation in controllers (e.g., "USER" or "ADMIN")
     * uses this method to verify that the GameUser’s assigned role set
     * contains the necessary role.
     */
    @Override
    public boolean authorize(GameUser user, String role) {

        // FIXED: Check if user has the required role
        if (user != null && user.getRoles() != null && user.getRoles().contains(role)) {
            return true; // Authorized access
        }

        // If the user lacks the role or is null, deny access
        return false;
    }
}
